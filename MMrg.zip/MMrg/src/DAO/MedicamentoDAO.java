package DAO;

import BEAN.Medicamento;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class MedicamentoDAO {

    public Vector<Medicamento> listarMedicamentos(boolean sw, String nombreBusq){
        Vector<Medicamento> lista = new Vector<>();
        DbBean con = new DbBean();
        String sql;

        if(sw == false){
            sql = "SELECT * FROM Medicamentos";
        } else {
            sql = "SELECT * FROM Medicamentos WHERE Nombre LIKE '%" + nombreBusq + "%'";
        }

        try {
            ResultSet rs = con.resultadoSQL(sql);
            while(rs.next()){
                Medicamento m = new Medicamento();
                m.setMedicamentoID(rs.getInt("MedicamentoID"));
                m.setCategoriaID(rs.getInt("CategoriaID"));
                m.setProveedorID(rs.getInt("ProveedorID"));
                m.setNombre(rs.getString("Nombre"));
                m.setDescripcion(rs.getString("Descripcion"));
                m.setPrecio(rs.getDouble("Precio"));
                m.setStock(rs.getInt("Stock"));
                m.setFechaExpiracion(rs.getDate("FechaExpiracion"));
                lista.add(m);
            }
        } catch(SQLException e){
            e.printStackTrace();
        }
        return lista;
    }

    public void insertar(Medicamento m){
        DbBean con = new DbBean();
        String sql = "INSERT INTO Medicamentos (MedicamentoID, CategoriaID, ProveedorID, Nombre, Descripcion, Precio, Stock, FechaExpiracion) "
                   + "VALUES ("+ m.getMedicamentoID() +", "+ m.getCategoriaID() +", "+ m.getProveedorID() +", '"
                   + m.getNombre() +"', '"+ m.getDescripcion() +"', "+ m.getPrecio() +", "+ m.getStock() +", '"
                   + new java.sql.Date(m.getFechaExpiracion().getTime()) +"')";

        try {
            con.ejecutaSQL(sql);
        } catch(SQLException e){
            e.printStackTrace();
        }
    }

    public void actualizar(Medicamento m){
        DbBean con = new DbBean();
        String sql = "UPDATE Medicamentos SET "
                + "CategoriaID = "+ m.getCategoriaID() +", "
                + "ProveedorID = "+ m.getProveedorID() +", "
                + "Nombre = '"+ m.getNombre() +"', "
                + "Descripcion = '"+ m.getDescripcion() +"', "
                + "Precio = "+ m.getPrecio() +", "
                + "Stock = "+ m.getStock() +", "
                + "FechaExpiracion = '"+ new java.sql.Date(m.getFechaExpiracion().getTime()) +"' "
                + "WHERE MedicamentoID = " + m.getMedicamentoID();

        try {
            con.ejecutaSQL(sql);
        } catch(SQLException e){
            e.printStackTrace();
        }
    }

    // Regresar descripción de categoría -> combobox
    public Vector<String> cargarCategorias(){
        Vector<String> lista = new Vector<>();
        DbBean con = new DbBean();
        String sql = "SELECT DescCategoria FROM Categoria";

        try{
            ResultSet rs = con.resultadoSQL(sql);
            while(rs.next()){
                lista.add(rs.getString(1));
            }
        } catch(SQLException e){
            e.printStackTrace();
        }

        return lista;
    }

    // Regresar nombre de proveedor -> combobox
    public Vector<String> cargarProveedores(){
        Vector<String> lista = new Vector<>();
        DbBean con = new DbBean();
        String sql = "SELECT Nombre FROM Proveedores";

        try{
            ResultSet rs = con.resultadoSQL(sql);
            while(rs.next()){
                lista.add(rs.getString(1));
            }
        } catch(SQLException e){
            e.printStackTrace();
        }

        return lista;
    }
}
