package DAO;

import BEAN.Empresa;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.util.Vector;

public class EmpresaDAO {

    public Vector<Empresa> listaEmpresa(boolean sw, String cad) {
        DbBean con = new DbBean();
        Vector<Empresa> lista = new Vector<>();
        String sql = "SELECT EmpresaID, descEmpresa, RUC, contacto, tlfConta, web FROM Empresa";


        if (sw == true) {
            sql += " where descEmpresa like '" + cad.replace("'", "''") + "%'";
        }

        sql += " ORDER BY descEmpresa";

        ResultSet result = null;
        try {
            result = con.resultadoSQL(sql);
            while (result.next()) {
                Empresa emp = new Empresa();
                emp.setEmpresaId(result.getInt(1));
                emp.setDescEmpresa(result.getString(2));
                emp.setRUC(result.getString(3));
                emp.setContacto(result.getString(4));
                emp.setTlfConta(result.getString(5));
                emp.setWeb(result.getString(6));
                lista.add(emp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (result != null) result.close();
            } catch (Exception e) {
            }
            try {
                con.desconecta();
            } catch (Exception e) {
            }
        }

        return lista;
    }

    public void insertarEmpresa(Empresa emp) {
        DbBean con = new DbBean();
        String sql;

        try {
            sql = "insert into Empresa(EmpresaID, descEmpresa, RUC, contacto, tlfConta, web) values("
                    + emp.getEmpresaId() + ", '"
                    + emp.getDescEmpresa().replace("'", "''") + "', '"
                    + emp.getRUC().replace("'", "''") + "', '"
                    + emp.getContacto().replace("'", "''") + "', '"
                    + emp.getTlfConta().replace("'", "''") + "', '"
                    + emp.getWeb().replace("'", "''") + "')";
            con.ejecutaSQL(sql);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                con.desconecta();
            } catch (Exception e) {
            }
        }
    }

    public void actualizarEmpresa(Empresa emp) {
        DbBean con = new DbBean();
        String sql;

        try {
            sql = "update Empresa set "
                    + "descEmpresa = '" + emp.getDescEmpresa().replace("'", "''") + "', "
                    + "RUC = '" + emp.getRUC().replace("'", "''") + "', "
                    + "contacto = '" + emp.getContacto().replace("'", "''") + "', "
                    + "tlfConta = '" + emp.getTlfConta().replace("'", "''") + "', "
                    + "web = '" + emp.getWeb().replace("'", "''") + "' "
                    + "where EmpresaID = " + emp.getEmpresaId();

            con.ejecutaSQL(sql);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                con.desconecta();
            } catch (Exception e) {
            }
        }
    }

    public boolean existeRUC(String ruc) {
    DbBean con = new DbBean();
    ResultSet rs = null;
    boolean existe = false;

    try {
        String sql = "select RUC from Empresa where RUC = '" 
                + ruc.replace("'", "''") + "'";

        rs = con.resultadoSQL(sql);

        if (rs.next()) {   
            existe = true;
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    try {
        if (rs != null) rs.close();
    } catch (Exception e) {}

    try {
        con.desconecta();
    } catch (Exception e) {}

    return existe;
}

    
}
