package DAO;

import BEAN.Proveedor;
import UTIL.DbBean;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class ProveedorDAO {

    public Vector<Proveedor> listaProveedores(boolean sw, String cad) {
        DbBean con = new DbBean();
        Vector<Proveedor> lista = new Vector<>();
        String sql = "SELECT * FROM Proveedores";

        if (sw) {
            sql += " WHERE Nombre LIKE '" + cad + "%'";
        }

        try {
            ResultSet res = con.resultadoSQL(sql);
            while (res.next()) {
                Proveedor prov = new Proveedor(
                    res.getInt("ProveedorID"),
                    res.getString("Nombre"),
                    res.getString("NombreContacto"),
                    res.getString("Direccion"),
                    res.getString("Ciudad"),
                    res.getString("Telefono"),
                    res.getInt("Estado")
                );
                lista.add(prov);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { con.desconecta(); } catch (SQLException e) {}
        }
        return lista;
    }

    public void insertaProveedor(Proveedor p) {
        DbBean con = new DbBean();
        String sql = "INSERT INTO Proveedores (ProveedorID,Nombre,NombreContacto,Direccion,Ciudad,Telefono,Estado) VALUES(" +
                     p.getProveedorID() + ", '" + 
                     p.getNombre() + "', '" + 
                     p.getNombreContacto() + "', '" + 
                     p.getDireccion() + "', '" + 
                     p.getCiudad() + "', '" + 
                     p.getTelefono() + "', " + 
                     p.getEstado() + ")";
        try {
            con.ejecutaSQL(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { con.desconecta(); } catch (SQLException e) {}
        }
    }

    public void actualizaProveedor(Proveedor p) {
        DbBean con = new DbBean();
        String sql = "UPDATE Proveedores SET " +
                     "Nombre='" + p.getNombre() + "', " +
                     "NombreContacto='" + p.getNombreContacto() + "', " +
                     "Direccion='" + p.getDireccion() + "', " +
                     "Ciudad='" + p.getCiudad() + "', " +
                     "Telefono='" + p.getTelefono() + "', " +
                     "Estado=" + p.getEstado() + 
                     " WHERE ProveedorID=" + p.getProveedorID();
        try {
            con.ejecutaSQL(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { con.desconecta(); } catch (SQLException e) {}
        }
    }
}
